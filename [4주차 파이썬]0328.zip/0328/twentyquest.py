import random

com = random.randrange(1, 21)
user = -1
while True :
    user = int(input('1~20 사이의 수 입력 : '))
    if com == user :
        print('맞췄습니다.')
        break
    elif com > user :
        print('입력한 값보단 더 큰 수 입니다.')
    else :
        print('입력한 값보단 더 작은 수 입니다.')