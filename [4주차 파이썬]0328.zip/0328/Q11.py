map(int, ['23','55','75'])

listex = map(int, ['23','55','75'])
print(listex)

a, b, c = map(int, ['23','55','75'])
print(a, b, c)

listex = list(map(int, ['23','55','75']))
print(listex)