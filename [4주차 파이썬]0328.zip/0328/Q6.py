oddlist = list(range(1, 101, 2))
print(oddlist)
sum = 0
for i in oddlist:
    sum = sum + i
print('list안의 데이터 합 = ', sum)