arr = [20,30,10,5,20,9]

arr.append(50)                      # 리스트 맨 뒤에 새 항목으로 50 저장
print('.append(50) >', arr)

b = arr.pop()                       # 리스트 맨 뒤 항목 삭제
print('.pop() >', arr, b)

arr.insert(1, 60)                   # 1번 위치에 60 삽입, 나머지는 뒤로 밀림
print('.insert(1, 60) >', arr)

arr.remove(20)                      # 항목삭제: 맨 처음 나오는 20 삭제
print('.insert(1, 60) >', arr)    

arr.clear()                         # 리스트 값 모두 삭제
print('.clear() >', arr)

arr = [20,30,10,5,20,9]

x = arr.index(30)                   # 30이 있는 위치의 인덱스 알려줌
print('.index(30) >', x)

x = arr.count(20)                   # 리스트에 20이 몇개 있는지 알려줌
print('.count(20)O >', x)

arr.sort()                          # 리스트 오름차순 정렬
print('.sort() >', arr)

arr.reverse()                       # 리스트 내림차순 정렬
print('.reverse() >', arr)

#보통 리스트에서 있는 값을 삭제할때는 아래 방식을 자주 씀
#만약 값이 없는데 remove를 진행하면 오류가 발생함

#if 20 in arr :
#    print(arr.index(20))
#    arr.remove(20)
#print()