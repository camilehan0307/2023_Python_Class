import random as r
import time as t

slot = [0]*3
n = (int(input('몇번을 반복하겠습니까? : ')))

for i in range(n):
    for k in range(3) :
        slot[k] = r.randrange(7, 10)
        print('%d ' % slot[k], end = '')
        t.sleep(1)
    if slot[0] + slot[1] + slot[2] == 21 :
        print('\n잭팟이 터졌네요')
    else  :
        print('\n아까워\n')