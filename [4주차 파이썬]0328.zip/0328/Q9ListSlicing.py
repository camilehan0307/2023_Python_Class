arr = [0,1,2,3,4,5,6,7,8,9]

#arr[a:b]    a<= n < b

print(arr[2:5]) #2~4까지만 출력
print(arr[2:])  #2부터 끝까지
print(arr[:5])  #처음부터 4까지
print(arr[:])   #처음부터 끝까지
print(arr[-1])  # 맨 뒤
print(arr[-5:-1])   #