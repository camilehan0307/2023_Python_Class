import random

score = 0

for k in range(5):
    correct = False
    stack = 0
    num1 = random.randint(10, 99)
    num2 = random.randint(10, 99)

    while stack < 3 and not correct:
        print('%d + %d = ' % (num1, num2), end = '')
        ans = int(input())
        if ans == num1 + num2:
            print('정답입니다.')
            correct = True
            score += (20-stack*3)
        else :
            print('다시 시도하세요.')
        stack += 1
print('score=%d' %score)