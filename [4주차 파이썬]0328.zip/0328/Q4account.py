account=[127890, 57800, 1200170]

sum=0
for k in range(3) :
    sum += account[k]
print('account money : %d원', sum)