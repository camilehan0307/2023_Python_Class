
n = int(input("몇개의 데이터를 처리할 것인가 : "))
list = [0]*n
sum = 0
max = 0
min = 0

print('%d개의 데이터를 입력 : ' % n)
for i in range(n):
    list[i] = int(input())
    sum += list[i]
    max = list[0]
    min = list[0]
    if(max<list[i]):
        max = list[i]
    if(min>list[i]):
        min = list[i]

print('리스트 데이터의 합, 평균, 최대, 최소값: %d, %.2f, %d, %d' % (sum, sum/n, max, min))