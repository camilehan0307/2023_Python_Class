print('구구단을 출력해본다')
answer = 0
for i in range(2, 10):
    print('\n%d단 : ' % i, end = '')
    for j in range(1, 10):
        answer = i * j
        print('%d X %d = %d\t' % (i, j, answer), end = '')
    print('\n')
