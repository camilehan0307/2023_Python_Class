choice = int(input('만날까? 말까? (1/0) 입력 : '))
print('오늘부터 1일\n') if choice == 1 else print('다음 기회에~~\n')

choice = bool(int(input('만날까? 말까? (1/0) 입력 : ')))
print('오늘부터 1일\n') if choice else print('다음 기회에~~\n')
