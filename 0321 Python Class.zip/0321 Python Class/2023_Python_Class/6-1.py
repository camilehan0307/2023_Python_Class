n = int(input('1부터 n까지의 짝수 합을 구하기 위한 n값을 입력하시오. : '))
sum = 0
digit = 2

while (digit <= n):
    sum = sum + digit
    digit = digit + 2
print('1부터 %d까지의 짝수 합은 %d 입니다.' % (n, sum))

    
