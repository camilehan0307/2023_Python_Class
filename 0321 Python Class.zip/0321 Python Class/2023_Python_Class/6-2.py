n = int(input('1부터 n까지의 짝수 합을 구하기 위한 n값을 입력하시오. : '))
sum = 0

for digit in range(2, n+1, 2):
    sum = sum + digit
print('1부터 %d 까지의 짝수 합은 %d 이다.'% (n, sum))
