import random

gnum = 0

while True:
    user = int(input('가위0 바위1 보2 중 하나를 고르시오 : '))
    com = random.randrange(3) 
    if user == 0 or user == 1 or user == 2:
        print('user = %d, com = %d' % (user, com))
        if user == com:
            print('비겼습니다!')
        elif (user == 0 and com == 2) or (user == 1 and com == 0) or (user == 3 and com == 1):
            print('user가 이겼습니다!')
        else:
            print('com이 이겼습니다.')
    else: 
           print('%d회 가위바위보 == END of gmae ==' % gnum)
           break
    gnum += 1
