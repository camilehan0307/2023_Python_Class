nomalpay=int(input('기본 통신비: '))
nomaldata=int(input('기본 데이터량: '))
pluspay=int(input('1기가당 추가 통신비: '))
nomaluse=int(input('한 달 기본 사용량: '))
total=(nomaluse-5)*3800+nomalpay
infinite=int(input('무제한 요금: '))
print('5기가까지 %d원' % nomalpay)
print('%d기가 사용하면 %d원' % (nomaluse, total))

if total>infinite :
    print('무제한 요금제 추천합니다.')
else :
    print('특판 요즘제를 추천합니다.')
