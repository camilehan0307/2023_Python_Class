num1 = int(input('첫 번째 수: '))
num2 = int(input('두 번째 수: '))

print('\n%d와 %d은 같은가? %s' % (num1, num2, num1 == num2))
print('\n%d보다 %d이 큰가? %s' % (num1, num2, num1 <= num2))
print('\n%d가 %d보다 큰가? %s' % (num1, num2, num1 >= num2))
