person=int(input('MT참가 인원수: '))
pack=person//12
thing=person%12

print('묶음 개수: %d' % pack)
print('낱개 개수: %d' % thing)
