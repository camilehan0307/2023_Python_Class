price=int(input('기계값 입력: '))
1150000
used=int(input('사용 개월 수: '))
18
nuse=24-used
mpay=price/24
print('\n매달 내는 돈 =%.1f원' % mpay)
print('남은 약정기간 = %d개월' % nuse)
print('위약금 = %.1f' % (mpay*nuse))
