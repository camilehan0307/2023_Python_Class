num1=int(input('첫 번째 수: '))
num2=int(input('두 번째 수: '))

print('\n둘 다 0인가? %s' % (num1 == 0 and num2 == 0))
print('양수가 있는가? %s' % (num1 >= 1 or num2 >= 1))
print('True의 반대는? %s' % (not True))
