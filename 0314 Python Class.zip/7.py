person=int(input('MT 참가 인원수: '))
amount=int(input('1인당 소모 생수 개수: '))

wtotal=person*amount
pack=wtotal//15
bottle=wtotal%15
total_cost=(pack*10000)+(bottle*900)

print('\n필요한 생수 개수: %d개' % wtotal)
print('\n생수 팩 구매량: %d개' % pack)
print('\n생수 낱개 구매량: %d개' % bottle)
print('\n생수 chd 구매비용: %d원' % total_cost)
