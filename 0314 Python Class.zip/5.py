print(2**10)
print(78//8)
print(78%8)
print(19-3**2)
