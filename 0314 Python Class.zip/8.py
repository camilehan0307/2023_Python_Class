num1=int(input('숫자 입력: '))

num1 = num1 + (num1%2)
print(num1)
